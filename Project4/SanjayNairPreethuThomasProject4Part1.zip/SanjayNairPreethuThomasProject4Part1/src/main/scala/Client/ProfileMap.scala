package Client

import scala.collection.mutable

object ProfileMap {
  val obj = mutable.HashMap[Int, Boolean]()
}
