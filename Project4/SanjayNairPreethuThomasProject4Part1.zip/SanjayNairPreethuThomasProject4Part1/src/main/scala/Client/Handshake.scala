package Client

case class Handshake(needResponse: Boolean, id: Int)
