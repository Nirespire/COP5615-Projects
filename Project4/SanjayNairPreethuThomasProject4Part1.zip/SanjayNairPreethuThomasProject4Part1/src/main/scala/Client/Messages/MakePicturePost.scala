package Client.Messages

case class MakePicturePost()
