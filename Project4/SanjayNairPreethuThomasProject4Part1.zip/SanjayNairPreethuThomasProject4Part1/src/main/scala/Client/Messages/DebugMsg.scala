package Client.Messages

case class DebugMsg()