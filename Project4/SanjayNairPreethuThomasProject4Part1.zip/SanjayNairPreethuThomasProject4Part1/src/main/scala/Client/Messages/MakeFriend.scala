package Client.Messages


case class MakeFriend(id:Int)
