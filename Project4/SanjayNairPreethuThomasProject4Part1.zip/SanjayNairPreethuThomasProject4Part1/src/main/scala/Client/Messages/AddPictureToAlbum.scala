package Client.Messages

case class AddPictureToAlbum()