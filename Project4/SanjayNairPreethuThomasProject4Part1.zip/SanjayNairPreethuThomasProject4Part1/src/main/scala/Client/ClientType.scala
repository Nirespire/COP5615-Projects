package Client

object ClientType extends Enumeration {
  type ClientType = Value
  val Active, Passive, ContentCreator = Value
}
