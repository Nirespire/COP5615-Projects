package Objects

import Objects.ObjectTypes.ListType.ListType

case class FriendList(owner: Int, profiles: Array[Int], list_type: ListType)
