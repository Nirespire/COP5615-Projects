package Client.Messages

case class MakePage()
