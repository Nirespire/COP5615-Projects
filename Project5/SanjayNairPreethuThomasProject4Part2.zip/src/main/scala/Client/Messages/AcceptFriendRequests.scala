package Client.Messages


case class AcceptFriendRequests()
