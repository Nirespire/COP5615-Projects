package Client.Messages

case class Activity()
