package Client.Messages

case class UpdatePicture()
