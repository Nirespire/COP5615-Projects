package Client.Messages


case class RequestFriend(id:Int)
