package Client.Messages


case class MakeAlbum()
