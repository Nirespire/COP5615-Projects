package Client.Messages

case class UpdateAlbum(cover:Int)
