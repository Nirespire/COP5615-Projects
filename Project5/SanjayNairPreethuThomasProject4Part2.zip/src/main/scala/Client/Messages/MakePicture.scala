package Client.Messages


case class MakePicture(albumID: Int)