package Objects

case class Picture(
                    var filename: String,
                    var base64Encoded: String
                  )
