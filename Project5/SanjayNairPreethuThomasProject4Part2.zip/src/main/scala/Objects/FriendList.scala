package Objects

case class FriendList(owner: Int, profiles: Array[Int])
