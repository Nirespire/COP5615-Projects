package Objects

case class Page(
                 about: String,
                 category: String,
                 cover: Int,
                 publicKey: Array[Byte]
               )