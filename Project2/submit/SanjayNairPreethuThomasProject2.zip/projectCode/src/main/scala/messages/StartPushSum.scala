package messages

case class StartPushSum(addS: Double=0, addW: Double=0)
