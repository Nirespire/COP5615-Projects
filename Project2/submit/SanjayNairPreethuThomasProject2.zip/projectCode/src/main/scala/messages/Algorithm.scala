package messages

object Algorithm extends Enumeration {
  type Algorithm = Value
  val pushSum, gossip = Value
}
