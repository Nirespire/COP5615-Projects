package messages

case class Setup()