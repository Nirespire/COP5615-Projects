package messages

case class InitialGossip()