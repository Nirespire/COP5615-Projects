package messages

case class SetupGossip (initialRumor : String)
