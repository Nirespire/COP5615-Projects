package messages

object Topology extends Enumeration {
  type Topology = Value
  val threeD, twoD, line, imp3D, imp2D, full = Value
}
