package messages

case class StartGossip(rumor:String)
